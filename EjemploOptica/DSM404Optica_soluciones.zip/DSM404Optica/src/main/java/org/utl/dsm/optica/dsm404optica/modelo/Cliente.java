package org.utl.dsm.optica.dsm404optica.modelo;

public class Cliente {

        private int idCliente;
        private String numeroUnico;
        private int estatus;
        private Persona persona;

        public Cliente() {
        }

        public int getIdCliente() {
            return idCliente;
        }

        public void setIdCliente(int idCliente) {
            this.idCliente = idCliente;
        }

        public String getNumeroUnico() {
            return numeroUnico;
        }

        public void setNumeroUnico(String numeroUnico) {
            this.numeroUnico = numeroUnico;
        }

        public int getEstatus() {
            return estatus;
        }

        public void setEstatus(int estatus) {
            this.estatus = estatus;
        }

        public Persona getPersona() {
            return persona;
        }

        public void setPersona(Persona persona) {
            this.persona = persona;
        }



}
