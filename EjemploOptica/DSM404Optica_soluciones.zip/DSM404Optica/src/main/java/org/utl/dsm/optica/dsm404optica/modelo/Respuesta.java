package org.utl.dsm.optica.dsm404optica.modelo;

public class Respuesta {
    String result;

    public Respuesta() {

    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}

