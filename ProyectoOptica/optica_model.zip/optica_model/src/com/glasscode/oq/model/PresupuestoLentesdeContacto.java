package com.glasscode.oq.model;

public class PresupuestoLentesdeContacto {
    private int idPresupuestoLentesContacto;
    private ExamendelaVista examenVista;
    private LenteContacto lenteContacto;
    private String clave;
    
    public PresupuestoLentesdeContacto(){
        
    }

    public int getIdPresupuestoLentesContacto() {
        return idPresupuestoLentesContacto;
    }

    public void setIdPresupuestoLentesContacto(int idPresupuestoLentesContacto) {
        this.idPresupuestoLentesContacto = idPresupuestoLentesContacto;
    }

    public ExamendelaVista getExamenVista() {
        return examenVista;
    }

    public void setExamenVista(ExamendelaVista examenVista) {
        this.examenVista = examenVista;
    }

    public LenteContacto getLenteContacto() {
        return lenteContacto;
    }

    public void setLenteContacto(LenteContacto lenteContacto) {
        this.lenteContacto = lenteContacto;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }
       
}
