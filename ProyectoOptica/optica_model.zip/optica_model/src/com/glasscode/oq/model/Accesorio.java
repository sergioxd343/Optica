package com.glasscode.oq.model;

public class Accesorio {

    private int idAccesorio;
    private Producto producto;

    public Accesorio() {

    }

    public int getIdAccesorio() {
        return idAccesorio;
    }

    public void setIdAccesorio(int idAccesorio) {
        this.idAccesorio = idAccesorio;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

}
