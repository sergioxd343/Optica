package com.glasscode.oq.model;

public class Presupuesto {
    private int idPresupuesto;
    private int idExamenVista;
    
    public Presupuesto(){
        
    }

    public int getIdPresupuesto() {
        return idPresupuesto;
    }

    public void setIdPresupuesto(int idPresupuesto) {
        this.idPresupuesto = idPresupuesto;
    }

    public int getIdExamenVista() {
        return idExamenVista;
    }

    public void setIdExamenVista(int idExamenVista) {
        this.idExamenVista = idExamenVista;
    }
    
    
    }
