package com.glasscode.oq.model;

public class Graduacion {
    private int idGraduacion;
    private Double esferaod;
    private Double esferaoi;
    private int cilindrood;
    private int cilindrooi;
    private int ejeoi;
    private int ejeod;
    private String dip;
    
    public Graduacion(){
        
    }

    public int getIdGraduacion() {
        return idGraduacion;
    }

    public void setIdGraduacion(int idGraduacion) {
        this.idGraduacion = idGraduacion;
    }

    public Double getEsferaod() {
        return esferaod;
    }

    public void setEsferaod(Double esferaod) {
        this.esferaod = esferaod;
    }

    public Double getEsferaoi() {
        return esferaoi;
    }

    public void setEsferaoi(Double esferaoi) {
        this.esferaoi = esferaoi;
    }

    public int getCilindrood() {
        return cilindrood;
    }

    public void setCilindrood(int cilindrood) {
        this.cilindrood = cilindrood;
    }

    public int getCilindrooi() {
        return cilindrooi;
    }

    public void setCilindrooi(int cilindrooi) {
        this.cilindrooi = cilindrooi;
    }

    public int getEjeoi() {
        return ejeoi;
    }

    public void setEjeoi(int ejeoi) {
        this.ejeoi = ejeoi;
    }

    public int getEjeod() {
        return ejeod;
    }

    public void setEjeod(int ejeod) {
        this.ejeod = ejeod;
    }

    public String getDip() {
        return dip;
    }

    public void setDip(String dip) {
        this.dip = dip;
    }
}
